{% include "Layout 1 Column" %}
<style>
.navbar-inverse {
    display:none;
}
.page-heading {
   display:none;
}
#gethelp
{
display:none;
}
footer .footer-bottom {
    display:none;
}
footer .footer-top {
     display:none;
}
</style>
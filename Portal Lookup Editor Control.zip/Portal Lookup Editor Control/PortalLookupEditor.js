<script>
var hashAttributes = new Array();
$(window).on('load', function() 
{
var lookupIDs, i;
for(i = 0; i < hashAttributes.length; i++) {
if(i == hashAttributes.length-1) //last value of array
{
   lookupIDs += hashAttributes[i];
}
if(i==0) // first value of array
{
   lookupIDs = hashAttributes[i]+',';
}
if(i>0 && i!=hashAttributes.length-1) // values between first & last
{
   lookupIDs += hashAttributes[i]+',';
}
}
$(lookupIDs).change(function () {
  var lookupValue = $(this).val();
  if(lookupValue == ''){
    $(this).next().next().children(':first-child').hide();
  }
  else{
    $(this).next().next().children(':first-child').show();
  }
});
});

$(document).ready(function(){
 makeHyperlink();
 $("#frameclose1").click(function(){
 $("#ediframe").removeAttr("src");
});
$("#frameclose2").click(function(){
 $("#ediframe").removeAttr("src");
});

function makeHyperlink()
{
var attributes = '{{ settings["Lookup Editor - Name"] }}';
var pages = '{{ settings["Lookup Editor - Page"] }}';
var roles = '{{ settings["Lookup Editor - Role"] }}';

var splitAttr = attributes.split(',');
var splitPages = pages.split(',');
var splitroles = roles.split(',');

var loggedInUserRoles = '{{user.roles}}';
var hasRole = false;
for(var r = 0; r < splitroles.length; r++)
{
//string trimmed = $.trim(splitroles[r]);
if(loggedInUserRoles.indexOf(splitroles[r].trim()) > -1)//has role
{
    hasRole = true;
    break;
}
}
if(hasRole == false)
{
    console.log("User doesn't have permission to Edit the lookup record");
    return;
}
if(splitAttr.length != splitPages.length)
{
    console.log("Portal Site Settings values are not correct");
    return;
}
for(var i = 0; i < splitAttr.length; i++)
{ 
    hashAttributes.push("#"+splitAttr[i].trim());
    $("#"+splitAttr[i].trim()+'_name').css({"color": "blue", "cursor": "pointer"});  
    $("#"+splitAttr[i].trim()+'_entityname').next().children(':first-child').before('<button data-name="'+splitAttr[i].trim()+'" data-page="'+splitPages[i].trim()+'" id="'+splitAttr[i].trim()+'_edit'+'" type="button" class="btn btn-default"><span class="sr-only"></span><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span></button>');  
    document.getElementById (splitAttr[i].trim()+'_edit').addEventListener ("click", openDialog, false);   
    if($('#'+splitAttr[i].trim()).val() == '')
    {
        $("#"+splitAttr[i].trim()+'_entityname').next().children(':first-child').hide();
    } 
    else
    {
        $("#"+splitAttr[i].trim()+'_entityname').next().children(':first-child').show();
    }
}
}
function openDialog()
{
 $("#ediframe").removeAttr("src");
 var schemaname = $(this).attr('data-name');
 var pagename = $(this).attr('data-page');
 var Id = $("#"+schemaname).val();
 var portalUrl = window.location.host;
 $('#ediframe').attr('src', 'https://'+portalUrl+'/'+pagename+'/?id='+Id);
 $('#classModal').modal('show');
}
});
</script>

<div id="classModal" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="classInfo" aria-hidden="true">
 <div class="modal-dialog modal-lg">
 <div class="modal-content">
 <div class="modal-header">
 <button id="frameclose1" type="button" class="close" data-dismiss="modal" aria-hidden="true">
 ×
 </button>
 <h4 class="modal-title" id="classModalLabel">
 View Details
 </h4>
 </div>
 <div class="modal-body"> 
 <iframe id="ediframe" src="" height="500px" width="100%" style="border-style: none;"></iframe>
 </div>
 <div class="modal-footer">
 <button id="frameclose2" type="button" class="btn btn-primary" data-dismiss="modal">
 Close
 </button>
 </div>
 </div>
 </div>
</div>